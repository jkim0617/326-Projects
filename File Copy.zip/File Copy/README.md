# File Copy
This program copies data from one text file to another. 
## Running the Program
This program is written in python and is ran in the command line using 
```
python filecopy.py <inputFile.txt> <copyFile.txt>
```
with the source content being the first argument and copy desitnation being the second. The copy file does not need to exist in the file, but the input file must.